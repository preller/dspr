Sebastian Raschka, 2015

# Python Machine Learning - Supplementary Datasets

## The Large Movie Review Dataset

- Used in chapters 8 and 9

The movie dataset converted into a 2-column CSV format: The first column (`review`) contains the text, and the second column (`sentiment`) denotes the polarity, where 0=negative and 1=positive. The first 25,000 are the training samples and the remaining 25,000 rows are the test samples from the "Large Movie Review Dataset v1.0," respectively.

- Source: [http://ai.stanford.edu/~amaas/data/sentiment/](http://ai.stanford.edu/~amaas/data/sentiment/)
