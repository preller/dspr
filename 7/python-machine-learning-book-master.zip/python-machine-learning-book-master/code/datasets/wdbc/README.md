Sebastian Raschka, 2015

# Python Machine Learning - Supplementary Datasets

## Breast Cancer Wisconsin (Diagnostic) Data Set

- Used in chapter 6
- Source: https://archive.ics.uci.edu/ml/datasets/Breast+Cancer+Wisconsin+(Diagnostic)
